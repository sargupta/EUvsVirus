//
//  InsideEuronextTests.swift
//  InsideEuronextTests
//
//  Created by Vinicius Granja on 4/25/20.
//  Copyright © 2020 Vinicius Granja. All rights reserved.
//

import XCTest
@testable import InsideEuronext

class InsideEuronextTests: XCTestCase {

    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
